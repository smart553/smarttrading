-- Run in Supabase SQL Editor. RLS ensures each signed-in user sees only their rows.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Trader',
  preferred_language text not null default 'en' check (preferred_language in ('en','ar')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  settings jsonb not null default '{"theme":"dark","default_market":"all"}'::jsonb,
  updated_at timestamptz not null default now()
);
create table if not exists public.watchlists (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null default 'My Watchlist',
  symbols text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, name)
);
alter table public.profiles enable row level security;
alter table public.user_settings enable row level security;
alter table public.watchlists enable row level security;
drop policy if exists "profile owner only" on public.profiles;
create policy "profile owner only" on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id);
drop policy if exists "settings owner only" on public.user_settings;
create policy "settings owner only" on public.user_settings for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "watchlists owner only" on public.watchlists;
create policy "watchlists owner only" on public.watchlists for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1)))
  on conflict (id) do nothing;
  insert into public.user_settings (user_id) values (new.id) on conflict (user_id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
