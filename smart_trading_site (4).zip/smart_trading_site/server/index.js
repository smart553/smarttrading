import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const PORT = Number(process.env.PORT || 3000);
const DATA_BASE = process.env.TWELVE_DATA_BASE_URL || 'https://api.twelvedata.com';
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '32kb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: 'draft-8', legacyHeaders: false }));
app.use(express.static(root, { extensions: ['html'] }));

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'Smart Trading API', marketDataConfigured: Boolean(process.env.TWELVE_DATA_API_KEY) }));

function validSymbol(symbol) {
  return typeof symbol === 'string' && /^[A-Za-z0-9.\/_:-]{1,32}$/.test(symbol.trim());
}
async function twelveData(endpoint, params) {
  if (!process.env.TWELVE_DATA_API_KEY) {
    const err = new Error('Market data is not configured. Add TWELVE_DATA_API_KEY to server environment.');
    err.status = 503;
    throw err;
  }
  const url = new URL(`${DATA_BASE}/${endpoint}`);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, String(v));
  url.searchParams.set('apikey', process.env.TWELVE_DATA_API_KEY);
  const response = await fetch(url, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(12_000) });
  if (!response.ok) { const err = new Error(`Market data provider returned HTTP ${response.status}`); err.status = 502; throw err; }
  const data = await response.json();
  if (data.status === 'error' || data.code >= 400) { const err = new Error(data.message || 'Market data provider error'); err.status = 502; throw err; }
  return data;
}
app.get('/api/market/quote', async (req, res) => {
  const symbol = String(req.query.symbol || '').trim();
  if (!validSymbol(symbol)) return res.status(400).json({ error: 'Provide a valid symbol, e.g. AAPL, EUR/USD, BTC/USD, or XAU/USD.' });
  try { res.set('Cache-Control', 'public, max-age=15'); res.json(await twelveData('price', { symbol })); }
  catch (e) { res.status(e.status || 502).json({ error: e.message || 'Unable to fetch quote.' }); }
});
app.get('/api/market/time-series', async (req, res) => {
  const symbol = String(req.query.symbol || '').trim();
  const interval = String(req.query.interval || '1day');
  const allowedIntervals = new Set(['1min','5min','15min','30min','1h','4h','1day','1week','1month']);
  const outputsize = Math.max(1, Math.min(500, Number.parseInt(String(req.query.outputsize || '100'), 10) || 100));
  if (!validSymbol(symbol)) return res.status(400).json({ error: 'Provide a valid symbol.' });
  if (!allowedIntervals.has(interval)) return res.status(400).json({ error: 'Unsupported interval.' });
  try { res.set('Cache-Control', 'public, max-age=60'); res.json(await twelveData('time_series', { symbol, interval, outputsize, format: 'JSON' })); }
  catch (e) { res.status(e.status || 502).json({ error: e.message || 'Unable to fetch time series.' }); }
});

app.get('*path', (req, res, next) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'API route not found.' });
  res.sendFile(path.join(root, 'index.html'), err => { if (err) next(err); });
});
app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error: 'Unexpected server error.' }); });
app.listen(PORT, () => console.log(`Smart Trading is running on http://localhost:${PORT}`));
