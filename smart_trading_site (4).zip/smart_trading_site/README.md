# Smart Trading — Ahmed Elmasry

Bilingual (English/Arabic) market-research starter with a teal/gold visual identity.

## Included

- `index.html` — existing responsive bilingual dashboard and local calculators.
- `market.html` — market quote/history screen that calls the server proxy.
- `account.html` — Supabase email/password auth, saved watchlists, and saved preferences.
- `server/index.js` — Express API proxy for Twelve Data; provider key stays server-side; basic security headers and rate limiting.
- `supabase/schema.sql` — profile/settings/watchlist tables, auth trigger, and row-level security policies.
- `.env.example` — environment-variable template.

## Run locally

Requirements: Node.js 20+.

```bash
cp .env.example .env
npm install
npm start
```

Open `http://localhost:3000`. The dashboard and account page can load without a market-data key, but `/api/market/quote` and `/api/market/time-series` return a configuration message until `TWELVE_DATA_API_KEY` is set. Keep `.env` private and never commit it.

## Configure live market data

1. Create an account with Twelve Data and select a plan that covers your symbols, update frequency, and licence/use case.
2. Put the API key in the server environment as `TWELVE_DATA_API_KEY`.
3. Restart/redeploy the server, open `/market.html`, and test a symbol supported by your plan.
4. Respect exchange licensing. Personal/internal display rights may not permit displaying data publicly to website visitors; obtain an external-display/commercial licence if needed.

Endpoints:

- `GET /api/health`
- `GET /api/market/quote?symbol=AAPL`
- `GET /api/market/time-series?symbol=EUR%2FUSD&interval=1day&outputsize=100`

## Configure accounts and persistence

1. Create a Supabase project.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. Open `/account.html`, enter the Supabase Project URL and the **public anon/publishable key**, then connect.
4. Sign up/sign in. Email confirmation settings depend on your Supabase Auth configuration.
5. RLS policies scope profiles, settings, and watchlists to the authenticated user.

The browser stores only the Supabase URL and public client key in local storage for convenience. Never put a Supabase `service_role` key in browser code. In production, configure allowed redirect URLs and email templates in Supabase Auth. For stronger production hygiene, move configuration into a build-time public environment variable rather than asking each user to enter it.

## Deploy

A straightforward deployment is Render, Railway, Fly.io, or another Node.js host for this Express app. Set `TWELVE_DATA_API_KEY` in the host's secret/environment settings, set `NODE_ENV=production`, deploy the repository, then attach a domain and enable HTTPS. Static-only hosting such as basic GitHub Pages cannot run this Express API; use a Node host or split the API into serverless functions.

For a commercial deployment, configure monitoring, backups, error tracking, stricter rate limits, email verification, password reset flows, and a clear privacy policy/terms. Consider moving the app to a typed frontend framework before substantial expansion. This starter is not a broker and does not execute trades.

## Limitations / safety

- Dashboard summary graphics and values are illustrative until connected to market APIs.
- Indicator and risk calculations are educational helpers and do not constitute a trading signal or financial advice.
- The API proxy currently provides quote and time-series endpoints only. Add provider-specific endpoints after checking symbol syntax, quotas, and licensing.
- Do not use this starter to store brokerage credentials or API secrets in the browser.
